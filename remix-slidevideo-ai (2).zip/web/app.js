/**
 * Remix SlideVideo AI - Web Application Engine
 * Handles PPTX parsing, Canvas rendering, Web Speech TTS, MediaRecorder video generation & UI state.
 */

// ================= THEMES CONFIGURATION =================
const THEMES = {
  dark_indigo: {
    name: 'نيلي ليلي حديث',
    bgStart: '#0b0f19',
    bgEnd: '#1e1b4b',
    cardBg: 'rgba(19, 27, 46, 0.85)',
    cardBorder: 'rgba(99, 102, 241, 0.25)',
    accent: '#6366f1',
    accentLight: '#818cf8',
    textMain: '#ffffff',
    textSub: '#94a3b8'
  },
  cyan_teal: {
    name: 'أزرق بحري مشرق',
    bgStart: '#082f49',
    bgEnd: '#0f172a',
    cardBg: 'rgba(12, 74, 110, 0.8)',
    cardBorder: 'rgba(6, 182, 212, 0.3)',
    accent: '#06b6d4',
    accentLight: '#67e8f9',
    textMain: '#ffffff',
    textSub: '#cbd5e1'
  },
  emerald_biz: {
    name: 'أخضر تنفيذي راقي',
    bgStart: '#022c22',
    bgEnd: '#0f172a',
    cardBg: 'rgba(6, 78, 59, 0.8)',
    cardBorder: 'rgba(16, 185, 129, 0.3)',
    accent: '#10b981',
    accentLight: '#6ee7b7',
    textMain: '#ffffff',
    textSub: '#d1fae5'
  },
  sunset_warm: {
    name: 'غروب دافئ أنيق',
    bgStart: '#2d1515',
    bgEnd: '#1c1917',
    cardBg: 'rgba(69, 26, 26, 0.8)',
    cardBorder: 'rgba(245, 158, 11, 0.3)',
    accent: '#f59e0b',
    accentLight: '#fde68a',
    textMain: '#ffffff',
    textSub: '#fef3c7'
  },
  clean_light: {
    name: 'أبيض ناصع احترافي',
    bgStart: '#f8fafc',
    bgEnd: '#e2e8f0',
    cardBg: 'rgba(255, 255, 255, 0.95)',
    cardBorder: 'rgba(79, 70, 229, 0.2)',
    accent: '#4f46e5',
    accentLight: '#6366f1',
    textMain: '#0f172a',
    textSub: '#475569'
  }
};

// ================= BUILT-IN SAMPLE PRESENTATIONS =================
const SAMPLE_PRESENTATIONS = {
  ai_edu: {
    title: "الذكاء الاصطناعي في التعليم المعاصر",
    language: "ar",
    slides: [
      {
        slideIndex: 1,
        title: "الذكاء الاصطناعي في التعليم المعاصر",
        bulletPoints: [
          "تحول جذري في أساليب التدريس والتعلم الرقمي",
          "تخصيص المناهج وفق وتيرة استيعاب كل طالب",
          "إعداد أجيال المستقبل لمهارات العصر التكنولوجي"
        ],
        fullVerbatimText: "الذكاء الاصطناعي في التعليم المعاصر. تحول جذري في أساليب التدريس والتعلم. تخصيص المناهج وفق وتيرة استيعاب كل طالب. إعداد أجيال المستقبل لمهارات العصر الرقمي.",
        durationSeconds: 8.5
      },
      {
        slideIndex: 2,
        title: "أهم المزايا والفوائد للطلاب",
        bulletPoints: [
          "مساعد ذكي متاح على مدار الساعة للإجابة عن التساؤلات",
          "تقييم فوري وتغذية راجعة دقيقة للمهام والواجبات",
          "تحويل المفاهيم المعقدة إلى شروحات مرئية تفاعلية"
        ],
        fullVerbatimText: "أهم المزايا والفوائد للطلاب. مساعد ذكي متاح على مدار الساعة للإجابة عن التساؤلات. تقييم فوري وتغذية راجعة دقيقة للمهام والواجبات. تحويل المفاهيم المعقدة إلى شروحات مرئية تفاعلية.",
        durationSeconds: 9.0
      },
      {
        slideIndex: 3,
        title: "تمكين المعلمين ورفع الكفاءة الأكاديمية",
        bulletPoints: [
          "أتمتة الأعمال الإدارية وتصحيح الاختبارات التلقائي",
          "توفير وقت أكبر للتركيز على الجانب الإنساني والتوجيه",
          "تحليلات بيانية دقيقة لمستوى تقدم الفصل الدراسي"
        ],
        fullVerbatimText: "تمكين المعلمين ورفع الكفاءة الأكاديمية. أتمتة الأعمال الإدارية وتصحيح الاختبارات التلقائي. توفير وقت أكبر للتركيز على الجانب الإنساني والتوجيه. تحليلات بيانية دقيقة لمستوى تقدم الفصل الدراسي.",
        durationSeconds: 8.8
      },
      {
        slideIndex: 4,
        title: "خاتمة وتوصيات المستقبل",
        bulletPoints: [
          "الاستثمار المستمر في تدريب الكوادر التعليمية",
          "مراعاة أخلاقيات الذكاء الاصطناعي وحماية خصوصية الطلاب",
          "التعليم التفاعلي جسر رئيسي نحو الريادة العالمية"
        ],
        fullVerbatimText: "خاتمة وتوصيات المستقبل. الاستثمار المستمر في تدريب الكوادر التعليمية. مراعاة أخلاقيات الذكاء الاصطناعي وحماية خصوصية الطلاب. التعليم التفاعلي جسر رئيسي نحو الريادة العالمية.",
        durationSeconds: 9.0
      }
    ]
  },
  marketing: {
    title: "استراتيجيات التسويق الرقمي الحديث 2026",
    language: "ar",
    slides: [
      {
        slideIndex: 1,
        title: "استراتيجيات التسويق الرقمي الحديث 2026",
        bulletPoints: [
          "التحول من الإعلانات التقليدية إلى تجارب العملاء التفاعلية",
          "استخدام الذكاء الاصطناعي في تحليل سلوك المستهلك وتوقع الطلب",
          "بناء علامة تجارية قوية عبر قنوات التواصل المتعددة"
        ],
        fullVerbatimText: "استراتيجيات التسويق الرقمي الحديث 2026. التحول من الإعلانات التقليدية إلى تجارب العملاء التفاعلية. استخدام الذكاء الاصطناعي في تحليل سلوك المستهلك. بناء علامة تجارية قوية.",
        durationSeconds: 8.5
      },
      {
        slideIndex: 2,
        title: "صناعة المحتوى المرئي فائق التأثير",
        bulletPoints: [
          "مقاطع الفيديو القصيرة تتصدر أعلى معدلات التفاعل والمبيعات",
          "السرد القصصي المشوق الذي يلمس مشاعر الجمهور",
          "الاستعانة بالمؤثرين الصغار لبناء الثقة والمصداقية"
        ],
        fullVerbatimText: "صناعة المحتوى المرئي فائق التأثير. مقاطع الفيديو القصيرة تتصدر أعلى معدلات التفاعل. السرد القصصي المشوق الذي يلمس مشاعر الجمهور. الاستعانة بالمؤثرين الصغار.",
        durationSeconds: 8.5
      },
      {
        slideIndex: 3,
        title: "تحسين مسارات التحويل ومضاعفة المبيعات",
        bulletPoints: [
          "تصميم صفحات هبوط سريعة وسلسة متوافقة مع الهواتف الذكية",
          "اختبارات A/B المستمرة لتحسين نصوص وزر الشراء",
          "إعادة الاستهداف الذكي للزوار دون إزعاج"
        ],
        fullVerbatimText: "تحسين مسارات التحويل ومضاعفة المبيعات. تصميم صفحات هبوط سريعة وسلسة متوافقة مع الهواتف الذكية. اختبارات A/B المستمرة لتحسين نصوص وزر الشراء. إعادة الاستهداف الذكي.",
        durationSeconds: 9.0
      },
      {
        slideIndex: 4,
        title: "قياس مؤشرات الأداء والعائد على الاستثمار",
        bulletPoints: [
          "تتبع تكلفة اكتساب العميل وقيمته الدائمة بدقة",
          "لوحات تحكم لحظية لاتخاذ قرارات تسويقية مبنية على البيانات",
          "المرونة في تعديل الحملات لتعظيم الربحية المستدامة"
        ],
        fullVerbatimText: "قياس مؤشرات الأداء والعائد على الاستثمار. تتبع تكلفة اكتساب العميل وقيمته الدائمة بدقة. لوحات تحكم لحظية لاتخاذ قرارات تسويقية مبنية على البيانات.",
        durationSeconds: 8.5
      }
    ]
  }
};

// ================= GLOBAL APP STATE =================
let currentPresentation = JSON.parse(JSON.stringify(SAMPLE_PRESENTATIONS.ai_edu));
let activeSlideIndex = 0;
let currentThemeKey = 'dark_indigo';
let appSettings = {
  geminiApiKey: localStorage.getItem('GEMINI_API_KEY') || '',
  ttsRate: parseFloat(localStorage.getItem('TTS_RATE')) || 1.0,
  ttsPitch: parseFloat(localStorage.getItem('TTS_PITCH')) || 1.0
};
let generatedVideoBlobUrl = null;

// ================= INITIALIZATION =================
document.addEventListener('DOMContentLoaded', () => {
  initSettings();
  initPPTXFileInput();
  renderSlidePreview();
  renderThumbnails();
});

// Navigation Controller
function navigateTo(screenId) {
  ['screenHome', 'screenStudio', 'screenPlayer'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });

  ['navBtnHome', 'navBtnStudio', 'navBtnPlayer'].forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.classList.remove('active');
  });

  if (screenId === 'home') {
    document.getElementById('screenHome').classList.remove('hidden');
    document.getElementById('navBtnHome').classList.add('active');
  } else if (screenId === 'studio') {
    document.getElementById('screenStudio').classList.remove('hidden');
    document.getElementById('navBtnStudio').classList.add('active');
    populateStudioInputs();
    renderSlidePreview();
    renderThumbnails();
  } else if (screenId === 'player') {
    document.getElementById('screenPlayer').classList.remove('hidden');
    document.getElementById('navBtnPlayer').classList.add('active');
    if (generatedVideoBlobUrl) {
      const vid = document.getElementById('outputVideoElement');
      vid.src = generatedVideoBlobUrl;
    }
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Load Sample Presentation
function loadSamplePresentation(key) {
  const sample = SAMPLE_PRESENTATIONS[key];
  if (!sample) return;
  currentPresentation = JSON.parse(JSON.stringify(sample));
  activeSlideIndex = 0;
  navigateTo('studio');
}

// Populate Studio Inputs
function populateStudioInputs() {
  document.getElementById('studioPresentationTitle').textContent = currentPresentation.title;
  document.getElementById('studioPresentationMeta').textContent = 
    `${currentPresentation.slides.length} شرائح • اللغة: ${currentPresentation.language === 'ar' ? 'العربية' : currentPresentation.language}`;
  
  const slide = currentPresentation.slides[activeSlideIndex];
  if (!slide) return;

  document.getElementById('slideTitleInput').value = slide.title || '';
  document.getElementById('slideBulletsInput').value = (slide.bulletPoints || []).join('\n');
  document.getElementById('slideVerbatimInput').value = slide.fullVerbatimText || '';
  document.getElementById('slideDurationInput').value = slide.durationSeconds || 7;

  document.getElementById('activeSlideBadge').textContent = `الشريحة ${activeSlideIndex + 1} من ${currentPresentation.slides.length}`;
  document.getElementById('slideIndicatorText').textContent = `شريحة ${activeSlideIndex + 1} من ${currentPresentation.slides.length}`;
}

// Update Slide Data on input
function updateCurrentSlideData() {
  const slide = currentPresentation.slides[activeSlideIndex];
  if (!slide) return;

  slide.title = document.getElementById('slideTitleInput').value;
  slide.bulletPoints = document.getElementById('slideBulletsInput').value
    .split('\n')
    .map(s => s.trim())
    .filter(Boolean);
  slide.fullVerbatimText = document.getElementById('slideVerbatimInput').value;
  slide.durationSeconds = parseFloat(document.getElementById('slideDurationInput').value) || 6.0;

  renderSlidePreview();
  renderThumbnails();
}

// Slide Navigation
function prevSlide() {
  if (activeSlideIndex > 0) {
    activeSlideIndex--;
    populateStudioInputs();
    renderSlidePreview();
    renderThumbnails();
  }
}

function nextSlide() {
  if (activeSlideIndex < currentPresentation.slides.length - 1) {
    activeSlideIndex++;
    populateStudioInputs();
    renderSlidePreview();
    renderThumbnails();
  }
}

function selectSlide(idx) {
  activeSlideIndex = idx;
  populateStudioInputs();
  renderSlidePreview();
  renderThumbnails();
}

// ================= PPTX FILE PARSER (JSZip Client-Side) =================
function initPPTXFileInput() {
  const input = document.getElementById('pptxFileInput');
  if (!input) return;

  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      showLoadingBanner('جاري قراءة وتحليل ملف البوربوينت...');
      const slides = await parsePptxFile(file);
      
      if (slides.length === 0) {
        alert('لم يتم العثور على شرائح قابلة للقراءة في هذا الملف.');
        return;
      }

      currentPresentation = {
        title: file.name.replace(/\.[^/.]+$/, ""),
        fileName: file.name,
        language: 'ar',
        slides: slides
      };
      activeSlideIndex = 0;
      navigateTo('studio');
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء قراءة ملف البوربوينت: ' + err.message);
    } finally {
      hideLoadingBanner();
    }
  });
}

async function parsePptxFile(file) {
  const zip = await JSZip.loadAsync(file);
  const slideFiles = [];

  // Find all slide XML files
  zip.forEach((relativePath) => {
    if (relativePath.match(/^ppt\/slides\/slide[0-9]+\.xml$/i)) {
      slideFiles.push(relativePath);
    }
  });

  // Sort sequentially
  slideFiles.sort((a, b) => {
    const numA = parseInt(a.match(/slide([0-9]+)\.xml/i)[1], 10);
    const numB = parseInt(b.match(/slide([0-9]+)\.xml/i)[1], 10);
    return numA - numB;
  });

  const parsedSlides = [];
  const parser = new DOMParser();

  for (let i = 0; i < slideFiles.length; i++) {
    const xmlText = await zip.file(slideFiles[i]).async('text');
    const doc = parser.parseFromString(xmlText, 'application/xml');

    // Extract text nodes
    const textNodes = doc.getElementsByTagNameNS('*', 't');
    const paragraphs = doc.getElementsByTagNameNS('*', 'p');
    
    let title = "";
    const bullets = [];
    const fullTexts = [];

    for (let p of paragraphs) {
      const textsInP = [];
      const tElements = p.getElementsByTagNameNS('*', 't');
      for (let t of tElements) {
        if (t.textContent) textsInP.push(t.textContent);
      }
      const pCombined = textsInP.join(' ').trim();
      if (pCombined) {
        fullTexts.push(pCombined);
        if (!title) {
          title = pCombined;
        } else {
          bullets.push(pCombined);
        }
      }
    }

    if (!title && fullTexts.length > 0) {
      title = fullTexts[0];
    }

    parsedSlides.push({
      slideIndex: i + 1,
      title: title || `شريحة ${i + 1}`,
      bulletPoints: bullets.length > 0 ? bullets : [title],
      fullVerbatimText: fullTexts.join('.\n'),
      durationSeconds: Math.max(6, Math.min(25, fullTexts.join(' ').split(' ').length * 0.4))
    });
  }

  return parsedSlides;
}

// ================= RENDER CANVAS SLIDE PREVIEW =================
function renderSlidePreview() {
  const canvas = document.getElementById('slideCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const slide = currentPresentation.slides[activeSlideIndex];
  if (!slide) return;

  drawSlideOnCanvas(ctx, slide, canvas.width, canvas.height, currentThemeKey, activeSlideIndex + 1, currentPresentation.slides.length);
}

function drawSlideOnCanvas(ctx, slide, width, height, themeKey, currentNum, totalNum) {
  const theme = THEMES[themeKey] || THEMES.dark_indigo;

  // Background Gradient
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, theme.bgStart);
  gradient.addColorStop(1, theme.bgEnd);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Decorative ambient circles
  ctx.save();
  ctx.fillStyle = theme.accent + '15';
  ctx.beginPath();
  ctx.arc(width * 0.85, height * 0.2, 220, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = theme.accentLight + '10';
  ctx.beginPath();
  ctx.arc(width * 0.15, height * 0.85, 260, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Top Bar & Brand Badge
  ctx.save();
  ctx.font = 'bold 22px Cairo, sans-serif';
  ctx.fillStyle = theme.accentLight;
  ctx.fillText('Remix SlideVideo AI', 60, 65);

  ctx.font = '600 20px Cairo, sans-serif';
  ctx.fillStyle = theme.textSub;
  ctx.fillText(`الشريحة ${currentNum} / ${totalNum}`, width - 180, 65);
  ctx.restore();

  // Divider Line
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 95);
  ctx.lineTo(width - 60, 95);
  ctx.stroke();

  // Slide Title
  ctx.save();
  ctx.font = 'bold 44px Cairo, sans-serif';
  ctx.fillStyle = theme.textMain;
  ctx.direction = 'rtl';
  ctx.textAlign = 'right';

  // Truncate or wrap title
  wrapText(ctx, slide.title, width - 80, 160, width - 160, 56);
  ctx.restore();

  // Bullet Points Cards Container
  const bullets = slide.bulletPoints || [];
  const startY = 240;
  const cardHeight = Math.min(95, (height - startY - 90) / Math.max(1, bullets.length));

  bullets.slice(0, 4).forEach((bullet, idx) => {
    const cardY = startY + idx * (cardHeight + 16);
    
    // Card background
    ctx.save();
    ctx.fillStyle = theme.cardBg;
    ctx.strokeStyle = theme.cardBorder;
    ctx.lineWidth = 1.5;
    roundRect(ctx, 60, cardY, width - 120, cardHeight, 16, true, true);

    // Number indicator circle
    ctx.fillStyle = theme.accent;
    ctx.beginPath();
    ctx.arc(width - 110, cardY + cardHeight / 2, 22, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 20px Cairo, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${idx + 1}`, width - 110, cardY + cardHeight / 2);

    // Bullet text
    ctx.fillStyle = theme.textMain;
    ctx.font = '500 24px Cairo, sans-serif';
    ctx.direction = 'rtl';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    
    const maxTextWidth = width - 240;
    const textY = cardY + cardHeight / 2;
    wrapText(ctx, bullet, width - 150, textY, maxTextWidth, 30, 2);

    ctx.restore();
  });

  // Bottom Progress Track
  const progressRatio = currentNum / Math.max(1, totalNum);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fillRect(0, height - 8, width, 8);

  ctx.fillStyle = theme.accent;
  ctx.fillRect(0, height - 8, width * progressRatio, 8);
}

// Canvas Utility: Rounded Rectangle
function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

// Canvas Utility: Wrap Text
function wrapText(ctx, text, x, y, maxWidth, lineHeight, maxLines = 3) {
  if (!text) return;
  const words = text.split(' ');
  let line = '';
  let linesCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line, x, y);
      line = words[n] + ' ';
      y += lineHeight;
      linesCount++;
      if (linesCount >= maxLines - 1 && n < words.length - 1) {
        ctx.fillText(line + '...', x, y);
        return;
      }
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, y);
}

// Render Thumbnails
function renderThumbnails() {
  const container = document.getElementById('slidesThumbnailsContainer');
  if (!container) return;
  container.innerHTML = '';

  currentPresentation.slides.forEach((slide, idx) => {
    const thumb = document.createElement('div');
    thumb.className = `slide-thumb flex-shrink-0 w-32 p-3 rounded-xl bg-slate-800/90 text-right ${idx === activeSlideIndex ? 'active' : ''}`;
    thumb.onclick = () => selectSlide(idx);

    thumb.innerHTML = `
      <div class="text-[10px] text-slate-400 font-semibold mb-1">شريحة ${idx + 1}</div>
      <div class="text-xs text-white font-bold truncate">${slide.title || 'بدون عنوان'}</div>
      <div class="text-[10px] text-emerald-400 mt-2">${slide.durationSeconds}ث</div>
    `;
    container.appendChild(thumb);
  });
}

// Theme Change Handler
function onThemeChange(newTheme) {
  currentThemeKey = newTheme;
  renderSlidePreview();
}

// Language Change Handler
function onLanguageChange(lang) {
  currentPresentation.language = lang;
  document.getElementById('studioPresentationMeta').textContent = 
    `${currentPresentation.slides.length} شرائح • اللغة: ${lang}`;
}

// ================= WEB SPEECH API TTS (Text To Speech) =================
function playActiveSlideAudio() {
  const slide = currentPresentation.slides[activeSlideIndex];
  if (!slide || !('speechSynthesis' in window)) {
    alert('متصفحك لا يدعم خاصية تحويل النص إلى صوت (Web Speech API).');
    return;
  }

  window.speechSynthesis.cancel();
  const text = slide.fullVerbatimText || slide.title;
  const utterance = new SpeechSynthesisUtterance(text);
  
  // Set language code
  utterance.lang = currentPresentation.language === 'ar' ? 'ar-SA' : currentPresentation.language;
  utterance.rate = appSettings.ttsRate;
  utterance.pitch = appSettings.ttsPitch;

  window.speechSynthesis.speak(utterance);
}

// ================= FULL VIDEO GENERATOR (Canvas + MediaRecorder) =================
async function startGenerateVideo() {
  const overlay = document.getElementById('generationOverlay');
  const title = document.getElementById('genStepTitle');
  const subtitle = document.getElementById('genStepSubtitle');
  const bar = document.getElementById('genProgressBar');
  const percent = document.getElementById('genProgressPercent');

  overlay.classList.remove('hidden');

  try {
    const canvas = document.getElementById('slideCanvas');
    const ctx = canvas.getContext('2d');
    const slides = currentPresentation.slides;
    const totalSlides = slides.length;

    // Create stream from canvas at 30 FPS
    const canvasStream = canvas.captureStream(30);

    // Audio context for synthesized background tone & speech
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const dest = audioCtx.createMediaStreamDestination();
    
    // Gentle ambient tone generator
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.02, audioCtx.currentTime);
    osc.frequency.setValueAtTime(220, audioCtx.currentTime);
    osc.connect(gain);
    gain.connect(dest);
    osc.start();

    // Combine video track + audio track
    const combinedTracks = [...canvasStream.getVideoTracks(), ...dest.stream.getAudioTracks()];
    const combinedStream = new MediaStream(combinedTracks);

    let mimeType = 'video/webm;codecs=vp9';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm';
    }

    const mediaRecorder = new MediaRecorder(combinedStream, { mimeType });
    const chunks = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    const recordPromise = new Promise((resolve) => {
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        resolve(blob);
      };
    });

    mediaRecorder.start();

    // Loop through each slide with smooth animated transitions
    for (let i = 0; i < totalSlides; i++) {
      const slide = slides[i];
      const durationMs = (slide.durationSeconds || 6.0) * 1000;
      const startTime = Date.now();

      title.textContent = `جاري معالجة الشريحة ${i + 1} من ${totalSlides}...`;
      subtitle.textContent = `توليد الصوت ومزامنة المؤثرات البصرية`;

      // Read narration aloud via speech synthesis in parallel
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(slide.fullVerbatimText || slide.title);
        utter.lang = currentPresentation.language === 'ar' ? 'ar-SA' : currentPresentation.language;
        utter.rate = appSettings.ttsRate;
        utter.pitch = appSettings.ttsPitch;
        window.speechSynthesis.speak(utter);
      }

      // Animate frame by frame
      while (Date.now() - startTime < durationMs) {
        const elapsed = Date.now() - startTime;
        const slideProgress = elapsed / durationMs;
        const overallProgress = (i + slideProgress) / totalSlides;

        bar.style.width = `${Math.round(overallProgress * 100)}%`;
        percent.textContent = `${Math.round(overallProgress * 100)}%`;

        drawSlideOnCanvas(ctx, slide, canvas.width, canvas.height, currentThemeKey, i + 1, totalSlides);
        await new Promise(r => setTimeout(r, 33)); // ~30 FPS
      }
    }

    // Finish recording
    title.textContent = "جاري تجميع وحفظ الفيديو النهائي...";
    bar.style.width = '100%';
    percent.textContent = '100%';

    mediaRecorder.stop();
    osc.stop();
    audioCtx.close();

    const finalBlob = await recordPromise;
    generatedVideoBlobUrl = URL.createObjectURL(finalBlob);

    // Update Player Download Button & View
    const dlBtn = document.getElementById('btnDownloadVideo');
    dlBtn.href = generatedVideoBlobUrl;
    dlBtn.download = `${currentPresentation.title.replace(/\s+/g, '_')}_Video.webm`;
    
    document.getElementById('playerVideoTitle').textContent = `فيديو: ${currentPresentation.title}`;

    setTimeout(() => {
      overlay.classList.add('hidden');
      navigateTo('player');
    }, 600);

  } catch (err) {
    console.error(err);
    alert('حدث خطأ أثناء إنتاج الفيديو: ' + err.message);
    overlay.classList.add('hidden');
  }
}

// AI Text Enhancement with Gemini API
async function aiEnhanceSlideText() {
  const slide = currentPresentation.slides[activeSlideIndex];
  if (!slide) return;

  if (!appSettings.geminiApiKey) {
    alert('يرجى إدخال مفتاح Gemini API في قائمة الإعدادات لتفعيل هذه الميزة.');
    openSettingsModal();
    return;
  }

  try {
    const prompt = `أنت خبير في الإلقاء وتقديم العروض التقديمية. قم بتحسين النص التالي ليصبح نصاً صوتياً إلقائياً (Verbatim Script) جذاباً ومؤثراً ومناسباً للإلقاء المباشر دون حذف أي فكرة رئيسية:\nالعنوان: ${slide.title}\nالنقاط: ${slide.bulletPoints.join(', ')}\nالنص الحالي: ${slide.fullVerbatimText}`;

    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${appSettings.geminiApiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });

    const data = await res.json();
    const resultText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (resultText) {
      document.getElementById('slideVerbatimInput').value = resultText.trim();
      updateCurrentSlideData();
      alert('تم تحسين النص الصوتي للشريحة بنجاح ✨');
    }
  } catch (err) {
    alert('فشل الاتصال بالذكاء الاصطناعي: ' + err.message);
  }
}

// Settings Modal Management
function openSettingsModal() {
  document.getElementById('geminiApiKeyInput').value = appSettings.geminiApiKey || '';
  document.getElementById('ttsRateSlider').value = appSettings.ttsRate;
  document.getElementById('ttsRateVal').textContent = appSettings.ttsRate + 'x';
  document.getElementById('ttsPitchSlider').value = appSettings.ttsPitch;
  document.getElementById('ttsPitchVal').textContent = appSettings.ttsPitch;
  document.getElementById('settingsModal').classList.remove('hidden');
}

function closeSettingsModal() {
  document.getElementById('settingsModal').classList.add('hidden');
}

function saveSettings() {
  const key = document.getElementById('geminiApiKeyInput').value.trim();
  const rate = parseFloat(document.getElementById('ttsRateSlider').value);
  const pitch = parseFloat(document.getElementById('ttsPitchSlider').value);

  appSettings.geminiApiKey = key;
  appSettings.ttsRate = rate;
  appSettings.ttsPitch = pitch;

  localStorage.setItem('GEMINI_API_KEY', key);
  localStorage.setItem('TTS_RATE', rate.toString());
  localStorage.setItem('TTS_PITCH', pitch.toString());

  closeSettingsModal();
}

function initSettings() {
  document.getElementById('ttsRateVal').textContent = appSettings.ttsRate + 'x';
  document.getElementById('ttsPitchVal').textContent = appSettings.ttsPitch;
}

function showLoadingBanner(msg) {
  // Can be expanded as needed
}

function hideLoadingBanner() {
  // Can be expanded as needed
}
